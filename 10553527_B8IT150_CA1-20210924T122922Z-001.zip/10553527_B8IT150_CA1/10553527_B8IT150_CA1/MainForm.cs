﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10553527_B8IT150_CA1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void addBookBtn_Click(object sender, EventArgs e)
        {
            CreateBookForm createBook = new CreateBookForm();
            createBook.TopMost = true;
            createBook.TopLevel = false;
            createBook.FormBorderStyle = FormBorderStyle.None;
            mainPnl.Controls.Clear();
            mainPnl.Controls.Add(createBook);
            createBook.Show();
        }

        private void readBookBtn_Click(object sender, EventArgs e)
        {
            ReadBookForm readBook = new ReadBookForm();
            readBook.TopMost = true;
            readBook.TopLevel = false;
            readBook.FormBorderStyle = FormBorderStyle.None;
            mainPnl.Controls.Clear();
            mainPnl.Controls.Add(readBook);
            readBook.Show();
        }

        private void updateBookBtn_Click(object sender, EventArgs e)
        {
            UpdateBookForm updateBook = new UpdateBookForm();
            updateBook.TopMost = true;
            updateBook.TopLevel = false;
            updateBook.FormBorderStyle = FormBorderStyle.None;
            mainPnl.Controls.Clear();
            mainPnl.Controls.Add(updateBook);
            updateBook.Show();
        }
    }
}
